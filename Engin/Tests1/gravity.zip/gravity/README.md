# Gravity Simulation

A simple gravity simulation using Haskell and Gloss.

## Dependencies

* [GHC](https://wiki.haskell.org/Haskell_in_5_steps) (Haskell)
* [Gloss](https://hackage.haskell.org/package/gloss-1.1.1.0)